export interface User {
  id: string;
  created_at: Date;
  user_id: string;
  image_url: string;
  organization_id: string;
}

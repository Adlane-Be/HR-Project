export const avatars = [
  {
    id: 1,
    img: "/avatars/1.png",
  },
  {
    id: 2,
    img: "/avatars/2.png",
  },
  {
    id: 3,
    img: "/avatars/3.png",
  },
  {
    id: 4,
    img: "/avatars/4.png",
  },
  {
    id: 5,
    img: "/avatars/5.png",
  },
  {
    id: 6,
    img: "/avatars/6.png",
  },
  {
    id: 7,
    img: "/avatars/7.png",
  },
  {
    id: 8,
    img: "/avatars/8.png",
  },
];

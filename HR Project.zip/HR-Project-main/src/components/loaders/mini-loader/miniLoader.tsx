import styles from "./mini-loader.module.css";

function MiniLoader() {
  return (
    <div>
      <div className={styles.loader} />
    </div>
  );
}

export default MiniLoader;
